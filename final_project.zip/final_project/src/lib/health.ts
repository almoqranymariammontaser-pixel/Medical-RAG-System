import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export type Reading = {
  id: string;
  user_id: string;
  systolic: number;
  diastolic: number;
  pulse: number | null;
  note: string | null;
  measured_at: string;
};

export type Profile = {
  id: string;
  full_name: string | null;
  age: number | null;
  gender: string | null;
  target_systolic: number;
  target_diastolic: number;
  notes: string | null;
};

export function classify(systolic: number, diastolic: number) {
  if (systolic >= 180 || diastolic >= 110)
    return { label: "خطر — راجع الطوارئ", level: "danger" as const };
  if (systolic >= 140 || diastolic >= 90)
    return { label: "مرتفع", level: "high" as const };
  if (systolic >= 130 || diastolic >= 85)
    return { label: "مرتفع قليلاً", level: "warn" as const };
  if (systolic < 90 || diastolic < 60)
    return { label: "منخفض", level: "warn" as const };
  return { label: "ضمن النطاق المقبول", level: "ok" as const };
}

export function levelClasses(level: "ok" | "warn" | "high" | "danger") {
  switch (level) {
    case "danger":
      return "bg-red-500/20 text-red-200";
    case "high":
      return "bg-red-400/15 text-red-200";
    case "warn":
      return "bg-amber-400/15 text-amber-200";
    default:
      return "bg-ocean-300/15 text-ocean-300";
  }
}

export function useProfile(userId: string | undefined) {
  return useQuery({
    queryKey: ["profile", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Profile | null> => {
      const { data, error } = await supabase
        .from("profiles")
        .select("*")
        .eq("id", userId!)
        .maybeSingle();
      if (error) throw error;
      return data as Profile | null;
    },
  });
}

export function useSaveProfile(userId: string | undefined) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: Partial<Profile>) => {
      const { error } = await supabase
        .from("profiles")
        .upsert({ id: userId!, ...values });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["profile", userId] }),
  });
}

export function useReadings(userId: string | undefined) {
  return useQuery({
    queryKey: ["readings", userId],
    enabled: !!userId,
    queryFn: async (): Promise<Reading[]> => {
      const { data, error } = await supabase
        .from("readings")
        .select("*")
        .order("measured_at", { ascending: false })
        .limit(60);
      if (error) throw error;
      return (data ?? []) as Reading[];
    },
  });
}

export function useAddReading(userId: string | undefined) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (values: {
      systolic: number;
      diastolic: number;
      pulse?: number | null;
      note?: string | null;
    }) => {
      const { error } = await supabase.from("readings").insert({
        user_id: userId!,
        systolic: values.systolic,
        diastolic: values.diastolic,
        pulse: values.pulse ?? null,
        note: values.note ?? null,
      });
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["readings", userId] }),
  });
}

export function useDeleteReading(userId: string | undefined) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase.from("readings").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["readings", userId] }),
  });
}

export function formatDate(iso: string) {
  return new Date(iso).toLocaleString("ar-EG", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}