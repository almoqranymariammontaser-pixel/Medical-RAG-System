import { Link, useRouterState } from "@tanstack/react-router";
import {
  AlertTriangle,
  BookOpen,
  HeartPulse,
  Home,
  LogOut,
  MessageSquare,
  Settings,
} from "lucide-react";
import type { ReactNode } from "react";
import logo from "@/assets/nabd-logo.png";
import { useAuth } from "@/lib/auth";

const NAV_ITEMS = [
  { to: "/", label: "لوحتي", icon: Home },
  { to: "/chat", label: "المحادثة", icon: MessageSquare },
  { to: "/library", label: "المكتبة الصحية", icon: BookOpen },
  { to: "/measurements", label: "قياساتي", icon: HeartPulse },
  { to: "/settings", label: "الإعدادات", icon: Settings },
] as const;

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <img
        src={logo}
        alt="شعار نبض"
        width={48}
        height={48}
        className="h-12 w-12 rounded-2xl shadow-lg shadow-ocean-300/10"
      />
      <div>
        <p className="font-sora text-2xl font-bold tracking-tight text-ocean-300">
          نبض
        </p>
        {!compact && (
          <p className="text-[10px] tracking-widest text-white/40">
            مساعد ضغط الدم
          </p>
        )}
      </div>
    </div>
  );
}

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { user, signOut } = useAuth();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const name =
    (user?.user_metadata?.["full_name"] as string | undefined) ||
    user?.email?.split("@")[0] ||
    "مريض نبض";

  return (
    <div
      dir="rtl"
      className="flex min-h-dvh w-full bg-ocean-900 font-tajawal text-white/90"
    >
      <aside className="hidden w-72 shrink-0 flex-col gap-2 border-l border-white/5 bg-ocean-800/60 p-6 md:flex">
        <div className="mb-10">
          <Brand />
        </div>

        <nav className="flex flex-1 flex-col gap-2">
          {NAV_ITEMS.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex items-center gap-3 rounded-2xl p-4 text-sm font-bold transition-all ${
                  active
                    ? "bg-ocean-500/80 text-white shadow-lg shadow-ocean-500/10"
                    : "text-white/55 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>

        <button
          onClick={() => signOut()}
          className="flex items-center gap-3 rounded-2xl p-4 text-sm font-bold text-white/50 transition hover:bg-white/5 hover:text-white"
        >
          <LogOut className="h-5 w-5" />
          تسجيل الخروج
        </button>
      </aside>

      <main className="flex min-w-0 flex-1 flex-col">
        <header className="flex items-center justify-between gap-4 border-b border-white/5 px-5 py-4 md:px-8">
          <div className="min-w-0">
            <h1 className="truncate font-sora text-xl font-bold text-white md:text-2xl">
              {title}
            </h1>
            <p className="mt-0.5 text-xs text-white/40 md:text-sm">
              {subtitle ?? "مصدر تثقيفي فقط — وليس بديلاً عن استشارة الطبيب"}
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-3 rounded-[1.25rem] border border-white/5 bg-ocean-800/70 py-2 pl-4 pr-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-ocean-500 to-ocean-300">
              <span className="font-sora text-sm font-bold text-ocean-900">
                {name.slice(0, 1)}
              </span>
            </div>
            <div className="hidden leading-tight sm:block">
              <p className="max-w-[10rem] truncate text-sm font-bold text-white">
                {name}
              </p>
              <p className="text-[10px] font-bold text-ocean-300">المستخدم</p>
            </div>
          </div>
        </header>

        <div className="flex items-center gap-3 border-b border-red-400/15 bg-red-400/8 px-5 py-3 md:px-8">
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-red-400/80">
            <AlertTriangle className="h-4 w-4 text-ocean-900" />
          </div>
          <p className="text-[11px] leading-relaxed text-red-100/80 md:text-sm">
            <span className="font-bold">طوارئ:</span> ألم صدر، ضعف بنصف الجسم،
            صعوبة كلام، أو ضغط ≥ 180/110 — اطلب الإسعاف فوراً.
          </p>
        </div>

        <div className="flex-1">{children}</div>

        <nav className="sticky bottom-0 flex items-center justify-around border-t border-white/5 bg-ocean-800/95 px-2 py-2 backdrop-blur md:hidden">
          {NAV_ITEMS.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex flex-col items-center gap-1 rounded-xl px-3 py-2 text-[10px] font-bold ${
                  active ? "text-ocean-300" : "text-white/45"
                }`}
              >
                <Icon className="h-5 w-5" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </main>
    </div>
  );
}