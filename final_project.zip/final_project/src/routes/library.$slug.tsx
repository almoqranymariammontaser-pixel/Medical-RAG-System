import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { getArticle } from "@/lib/articles";

export const Route = createFileRoute("/library/$slug")({
  loader: ({ params }) => {
    const article = getArticle(params.slug);
    if (!article) throw notFound();
    return { article };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "المقال غير متاح — نبض" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const { article } = loaderData;
    return {
      meta: [
        { title: `${article.title} — المكتبة الصحية | نبض` },
        { name: "description", content: article.excerpt },
        { property: "og:title", content: `${article.title} — نبض` },
        { property: "og:description", content: article.excerpt },
        { property: "og:type", content: "article" },
        { name: "twitter:card", content: "summary_large_image" },
      ],
    };
  },
  component: ArticlePage,
  notFoundComponent: ArticleNotFound,
});

function ArticlePage() {
  const { article } = Route.useLoaderData();

  return (
    <AppShell title={article.title} subtitle={`${article.tag} · ${article.read} قراءة`}>
      <div className="p-5 md:p-8">
        <article className="mx-auto max-w-3xl rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6 md:p-8">
          <p className="text-sm leading-relaxed text-ocean-300">
            {article.excerpt}
          </p>

          {article.sections.map((section) => (
            <section key={section.heading} className="mt-7">
              <h2 className="mb-3 font-sora text-lg font-bold text-white">
                {section.heading}
              </h2>
              <div className="space-y-2.5">
                {section.body.map((p, i) => (
                  <p
                    key={i}
                    className="text-sm leading-loose text-white/65 md:text-base"
                  >
                    {p}
                  </p>
                ))}
              </div>
            </section>
          ))}

          <p className="mt-8 rounded-2xl bg-ocean-900/50 p-4 text-[11px] leading-relaxed text-white/40">
            محتوى تثقيفي عام مبني على دليل منظمة الصحة العالمية 2021، وليس بديلاً
            عن استشارة الطبيب المعالج.
          </p>

          <Link
            to="/library"
            className="mt-6 inline-flex items-center gap-2 text-xs font-bold text-ocean-300 hover:underline"
          >
            <ArrowRight className="h-3 w-3" />
            كل المقالات
          </Link>
        </article>
      </div>
    </AppShell>
  );
}

function ArticleNotFound() {
  return (
    <AppShell title="المقال غير موجود">
      <div className="p-8 text-sm text-white/55">
        <p>لم نجد هذا المقال.</p>
        <Link
          to="/library"
          className="mt-4 inline-block rounded-2xl bg-ocean-300 px-4 py-2.5 text-xs font-bold text-ocean-900"
        >
          العودة للمكتبة
        </Link>
      </div>
    </AppShell>
  );
}