# Welcome to your Lovable project

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Open your project in the [Lovable editor](https://lovable.dev) and keep building.

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: connect the project to GitHub and every change made in Lovable is committed straight to your repository.
- **Full ownership**: this code is yours. Push to your repository and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```

## Built with

- TanStack Start
- TypeScript
- React
- Tailwind CSS

## واجهة نبض البرمجية (REST API v1)

توثيق تفاعلي داخل التطبيق على المسار `/api-docs`.

القاعدة: `/api/public/v1` — كل الردود JSON (UTF-8) وتدعم CORS.
النقاط المحمية تحتاج ترويسة `Authorization: Bearer <access_token>` (توكن جلسة المستخدم)،
والوصول للبيانات محكوم بسياسات الأمان (RLS) فلا يرى أي مستخدم بيانات غيره.

| الطريقة | المسار | توكن | الوصف |
| --- | --- | --- | --- |
| GET | `/health` | لا | حالة الخدمة وقائمة النقاط |
| GET | `/articles` | لا | مقالات المكتبة (تصفية بـ `?tag=`) |
| GET | `/articles/:slug` | لا | مقال كامل |
| POST | `/chat` | لا | سؤال المساعد الذكي (`{ message, history? }`) |
| GET | `/profile` | نعم | الملف الشخصي والأهداف |
| PATCH | `/profile` | نعم | تحديث الملف الشخصي |
| GET | `/readings` | نعم | القراءات (`limit`, `offset`, `from`, `to`) |
| POST | `/readings` | نعم | تسجيل قراءة |
| GET | `/readings/:id` | نعم | قراءة واحدة |
| PATCH | `/readings/:id` | نعم | تعديل قراءة |
| DELETE | `/readings/:id` | نعم | حذف قراءة |
| GET | `/stats` | نعم | ملخص إحصائي (`?days=30`) |

مثال:

```bash
curl -X POST "$BASE_URL/api/public/v1/readings" \
  -H "Authorization: Bearer $ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"systolic":138,"diastolic":88,"pulse":76}'