import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, ArrowLeft, HeartPulse, Target, TrendingUp } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { ARTICLES } from "@/lib/articles";
import { useAuth, useRequireAuth } from "@/lib/auth";
import {
  classify,
  formatDate,
  levelClasses,
  useProfile,
  useReadings,
} from "@/lib/health";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "لوحتي الصحية — نبض لمتابعة ضغط الدم" },
      {
        name: "description",
        content:
          "لوحة شخصية تعرض آخر قياس لضغط دمك، متوسط أسبوعك، وهدفك العلاجي، مع مساعد تثقيفي مبني على دليل منظمة الصحة العالمية 2021.",
      },
      { property: "og:title", content: "لوحتي الصحية — نبض" },
      {
        property: "og:description",
        content: "تابع ضغط دمك وحالتك الصحية في لوحة واحدة بسيطة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  const { loading, session } = useRequireAuth();
  const { user } = useAuth();
  const { data: profile } = useProfile(user?.id);
  const { data: readings = [], isLoading } = useReadings(user?.id);

  if (loading || !session) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-ocean-900 font-tajawal text-white/60">
        جارٍ التحميل...
      </div>
    );
  }

  const latest = readings[0];
  const week = readings.filter(
    (r) =>
      new Date(r.measured_at).getTime() > Date.now() - 7 * 24 * 60 * 60 * 1000,
  );
  const avg = week.length
    ? {
        sys: Math.round(week.reduce((s, r) => s + r.systolic, 0) / week.length),
        dia: Math.round(week.reduce((s, r) => s + r.diastolic, 0) / week.length),
      }
    : null;
  const status = latest ? classify(latest.systolic, latest.diastolic) : null;
  const name =
    profile?.full_name ||
    (user?.user_metadata?.["full_name"] as string | undefined) ||
    user?.email?.split("@")[0];

  return (
    <AppShell
      title={`أهلاً ${name ?? "بك"} 👋`}
      subtitle="نظرة سريعة على حالتك الصحية اليوم"
    >
      <div className="grid gap-5 p-5 md:grid-cols-12 md:p-8">
        <div className="grid gap-5 sm:grid-cols-3 md:col-span-12">
          <StatCard
            icon={<HeartPulse className="h-5 w-5" />}
            label="آخر قياس"
            value={latest ? `${latest.systolic}/${latest.diastolic}` : "—"}
            hint={
              latest
                ? formatDate(latest.measured_at)
                : isLoading
                  ? "جارٍ التحميل"
                  : "لم تُضف أي قياس بعد"
            }
            badge={status?.label}
            badgeClass={status ? levelClasses(status.level) : undefined}
          />
          <StatCard
            icon={<TrendingUp className="h-5 w-5" />}
            label="متوسط ٧ أيام"
            value={avg ? `${avg.sys}/${avg.dia}` : "—"}
            hint={`${week.length} قياس هذا الأسبوع`}
          />
          <StatCard
            icon={<Target className="h-5 w-5" />}
            label="هدفك"
            value={`${profile?.target_systolic ?? 130}/${profile?.target_diastolic ?? 80}`}
            hint="يمكن تعديله من الإعدادات"
          />
        </div>

        <section className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6 md:col-span-7">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-bold text-white">أحدث قياساتك</h2>
            <Link
              to="/measurements"
              className="flex items-center gap-1 text-xs font-bold text-ocean-300 hover:underline"
            >
              إضافة قياس <ArrowLeft className="h-3 w-3" />
            </Link>
          </div>

          {readings.length === 0 ? (
            <p className="rounded-2xl bg-ocean-900/40 p-5 text-sm leading-relaxed text-white/50">
              لا توجد قياسات محفوظة. أضف قياسك الأول من صفحة «قياساتي» وسيظهر
              هنا مع تحليل حالتك.
            </p>
          ) : (
            <ul className="divide-y divide-white/5">
              {readings.slice(0, 5).map((r) => {
                const c = classify(r.systolic, r.diastolic);
                return (
                  <li
                    key={r.id}
                    className="flex items-center justify-between py-4"
                  >
                    <div>
                      <p className="font-bold">
                        <span className="font-sora text-2xl text-ocean-300">
                          {r.systolic}
                        </span>
                        <span className="text-white/30">/{r.diastolic}</span>
                        <span className="text-xs text-white/35"> ملم زئبق</span>
                      </p>
                      <p className="mt-1 text-xs text-white/40">
                        {formatDate(r.measured_at)}
                        {r.pulse ? ` · نبض ${r.pulse}` : ""}
                      </p>
                    </div>
                    <span
                      className={`rounded-full px-3 py-1 text-[11px] font-bold ${levelClasses(c.level)}`}
                    >
                      {c.label}
                    </span>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <div className="flex flex-col gap-5 md:col-span-5">
          <div className="rounded-[2rem] bg-gradient-to-br from-ocean-500/80 to-ocean-800 p-6">
            <div className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
              <Activity className="h-4 w-4 text-ocean-300" />
              تذكير اليوم
            </div>
            <p className="text-sm leading-relaxed text-white/75">
              {status?.level === "danger"
                ? "قراءتك الأخيرة مرتفعة جداً — توجّه للطوارئ أو اتصل بطبيبك فوراً."
                : status?.level === "high"
                  ? "قراءتك الأخيرة أعلى من الهدف. قلّل الملح، واصل أدويتك كما وصفها الطبيب، وأعد القياس بعد الراحة."
                  : "واصل القياس اليومي في نفس التوقيت، وسجّل النتيجة هنا لمتابعة اتجاه ضغطك."}
            </p>
            <Link
              to="/chat"
              className="mt-5 inline-block rounded-2xl bg-ocean-300 px-4 py-2.5 text-xs font-bold text-ocean-900"
            >
              اسأل المساعد الذكي
            </Link>
          </div>

          <div className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-bold text-white">مقالات مقترحة</h2>
              <Link
                to="/library"
                className="text-xs font-bold text-ocean-300 hover:underline"
              >
                المكتبة
              </Link>
            </div>
            <div className="flex flex-col gap-3">
              {ARTICLES.slice(0, 3).map((a) => (
                <Link
                  key={a.slug}
                  to="/library/$slug"
                  params={{ slug: a.slug }}
                  className="rounded-2xl bg-ocean-900/40 p-4 transition hover:bg-ocean-500/15"
                >
                  <p className="text-sm font-bold text-white">{a.title}</p>
                  <p className="mt-1 line-clamp-2 text-[11px] leading-snug text-white/40">
                    {a.excerpt}
                  </p>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function StatCard({
  icon,
  label,
  value,
  hint,
  badge,
  badgeClass,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  hint: string;
  badge?: string | undefined;
  badgeClass?: string | undefined;
}) {
  return (
    <div className="rounded-[1.75rem] border border-white/5 bg-ocean-800/50 p-6">
      <div className="mb-3 flex items-center gap-2 text-xs font-bold text-white/45">
        <span className="text-ocean-300">{icon}</span>
        {label}
      </div>
      <p className="font-sora text-3xl font-bold text-white">{value}</p>
      <p className="mt-2 text-[11px] text-white/40">{hint}</p>
      {badge && (
        <span
          className={`mt-3 inline-block rounded-full px-3 py-1 text-[11px] font-bold ${badgeClass}`}
        >
          {badge}
        </span>
      )}
    </div>
  );
}