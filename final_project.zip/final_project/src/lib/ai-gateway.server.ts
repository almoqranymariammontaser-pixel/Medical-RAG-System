import { createOpenAICompatible } from "@ai-sdk/openai-compatible";

/**
 * Creates a provider that talks to the Lovable AI Gateway.
 *
 * Server-only: this module reads `LOVABLE_API_KEY` and must never be imported
 * by client code. Use it from a server route or a `createServerFn` handler.
 *
 * Gateway base URL: https://ai.gateway.lovable.dev/v1
 * Auth header: Lovable-API-Key (NOT Authorization: Bearer)
 */
export function createLovableAiGatewayProvider(apiKey: string) {
  return createOpenAICompatible({
    name: "lovable-ai-gateway",
    baseURL: "https://ai.gateway.lovable.dev/v1",
    headers: {
      "Lovable-API-Key": apiKey,
    },
  });
}

/**
 * The default chat model used across the app.
 * A non-OpenAI vendor id → uses the openai-compatible chat path.
 */
export const DEFAULT_CHAT_MODEL = "google/gemini-3.7-flash";