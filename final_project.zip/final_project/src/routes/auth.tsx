import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, Mail, Lock, User } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable/index";
import { useAuth } from "@/lib/auth";
import { Brand } from "@/components/app-shell";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "تسجيل الدخول — نبض لمتابعة ضغط الدم" },
      {
        name: "description",
        content:
          "سجّل الدخول أو أنشئ حساباً في نبض لحفظ قياسات ضغط دمك ومتابعة حالتك الصحية في لوحة خاصة بك.",
      },
      { property: "og:title", content: "تسجيل الدخول — نبض" },
      {
        property: "og:description",
        content: "حساب واحد يحفظ قياساتك وملفك الصحي في نبض.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const { session } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (session) navigate({ to: "/", replace: true });
  }, [session, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setBusy(true);
    try {
      if (mode === "signup") {
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { full_name: fullName },
          },
        });
        if (signUpError) throw signUpError;
        setMessage(
          "تم إنشاء الحساب. إن طُلب تأكيد البريد، افتح رسالة التأكيد ثم سجّل الدخول.",
        );
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (signInError) throw signInError;
      }
    } catch (err) {
      const raw = err instanceof Error ? err.message : "حدث خطأ غير متوقع.";
      setError(
        raw.includes("Invalid login")
          ? "البريد الإلكتروني أو كلمة المرور غير صحيحة."
          : raw.includes("already registered")
            ? "هذا البريد مسجّل بالفعل — جرّب تسجيل الدخول."
            : raw,
      );
    } finally {
      setBusy(false);
    }
  };

  const google = async () => {
    setError(null);
    const result = await lovable.auth.signInWithOAuth("google", {
      redirect_uri: window.location.origin,
    });
    if (result.error) {
      setError("تعذّر تسجيل الدخول عبر Google. حاول مرة أخرى.");
      return;
    }
  };

  return (
    <div
      dir="rtl"
      className="flex min-h-dvh items-center justify-center bg-ocean-900 px-4 py-10 font-tajawal text-white/90"
    >
      <div className="w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <Brand />
        </div>

        <div className="rounded-[2rem] border border-white/5 bg-ocean-800/60 p-6 shadow-2xl md:p-8">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-2xl bg-ocean-900/60 p-1">
            {(["signin", "signup"] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`rounded-xl py-2.5 text-sm font-bold transition ${
                  mode === m
                    ? "bg-ocean-500/80 text-white"
                    : "text-white/50 hover:text-white"
                }`}
              >
                {m === "signin" ? "تسجيل الدخول" : "حساب جديد"}
              </button>
            ))}
          </div>

          <form onSubmit={submit} className="space-y-4">
            {mode === "signup" && (
              <Field
                icon={<User className="h-4 w-4" />}
                label="الاسم"
                value={fullName}
                onChange={setFullName}
                type="text"
                placeholder="اسمك الكامل"
              />
            )}
            <Field
              icon={<Mail className="h-4 w-4" />}
              label="البريد الإلكتروني"
              value={email}
              onChange={setEmail}
              type="email"
              placeholder="you@example.com"
              required
            />
            <Field
              icon={<Lock className="h-4 w-4" />}
              label="كلمة المرور"
              value={password}
              onChange={setPassword}
              type="password"
              placeholder="٦ أحرف على الأقل"
              required
            />

            {error && (
              <p className="rounded-xl border border-red-400/25 bg-red-400/10 p-3 text-xs text-red-100">
                {error}
              </p>
            )}
            {message && (
              <p className="rounded-xl border border-ocean-300/25 bg-ocean-300/10 p-3 text-xs text-ocean-300">
                {message}
              </p>
            )}

            <button
              type="submit"
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-ocean-300 py-3 text-sm font-bold text-ocean-900 shadow-lg shadow-ocean-300/15 transition hover:bg-ocean-300/90 disabled:opacity-50"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === "signin" ? "دخول" : "إنشاء الحساب"}
            </button>
          </form>

          <div className="my-5 flex items-center gap-3 text-[11px] text-white/30">
            <span className="h-px flex-1 bg-white/10" />
            أو
            <span className="h-px flex-1 bg-white/10" />
          </div>

          <button
            onClick={google}
            className="w-full rounded-2xl border border-white/10 bg-ocean-900/50 py-3 text-sm font-bold text-white/85 transition hover:border-ocean-300/40 hover:bg-ocean-500/15"
          >
            المتابعة باستخدام Google
          </button>

          <p className="mt-6 text-center text-[11px] leading-relaxed text-white/35">
            نبض مصدر تثقيفي فقط ولا يقدّم تشخيصاً طبياً. بياناتك مرتبطة بحسابك
            ولا يمكن لأي مستخدم آخر رؤيتها.
          </p>
        </div>
      </div>
    </div>
  );
}

function Field({
  icon,
  label,
  value,
  onChange,
  type,
  placeholder,
  required,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  onChange: (v: string) => void;
  type: string;
  placeholder?: string;
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-white/50">
        {label}
      </span>
      <span className="flex items-center gap-2 rounded-2xl border border-white/10 bg-ocean-900/50 px-4 focus-within:border-ocean-300/50">
        <span className="text-ocean-300">{icon}</span>
        <input
          type={type}
          value={value}
          required={required}
          placeholder={placeholder}
          onChange={(e) => onChange(e.target.value)}
          className="w-full bg-transparent py-3 text-sm text-white placeholder:text-white/25 focus:outline-none"
        />
      </span>
    </label>
  );
}