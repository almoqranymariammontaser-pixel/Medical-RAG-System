import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef } from "react";
import { useRequireAuth } from "@/lib/auth";
import { createThread, listThreads } from "@/lib/chat-store";

export const Route = createFileRoute("/chat/")({
  head: () => ({
    meta: [
      { title: "المحادثة مع المساعد — نبض" },
      {
        name: "description",
        content:
          "اسأل مساعد نبض التثقيفي عن ارتفاع ضغط الدم: الأدوية، القياس، التغذية والأعراض، بإجابات مبنية على دليل منظمة الصحة العالمية 2021.",
      },
      { property: "og:title", content: "المحادثة مع المساعد — نبض" },
      {
        property: "og:description",
        content: "إجابات عربية مبسّطة عن ارتفاع ضغط الدم من مصدر موثوق.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatIndexPage,
});

function ChatIndexPage() {
  const { loading, session } = useRequireAuth();
  const navigate = useNavigate();
  const started = useRef(false);

  useEffect(() => {
    if (loading || !session || started.current) return;
    started.current = true;
    (async () => {
      const threads = await listThreads();
      const target =
        threads[0] ?? (await createThread(session.user.id));
      navigate({
        to: "/chat/$threadId",
        params: { threadId: target.id },
        replace: true,
      });
    })().catch(() => {
      started.current = false;
    });
  }, [loading, session, navigate]);

  return (
    <div className="flex min-h-dvh items-center justify-center bg-ocean-900 font-tajawal text-white/60">
      جارٍ التحميل...
    </div>
  );
}