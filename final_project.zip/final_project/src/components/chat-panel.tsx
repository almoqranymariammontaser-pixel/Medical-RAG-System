import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport, type UIMessage } from "ai";
import { Send, Stethoscope, MessageSquare } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import {
  messageText,
  NEW_THREAD_TITLE,
  renameThread,
  saveMessage,
  touchThread,
} from "@/lib/chat-store";

const SUGGESTED_QUESTIONS = [
  "متى أبدأ أخذ دواء الضغط؟",
  "ما هو الضغط المستهدف لمريض السكري؟",
  "كيف أقيس ضغطي بطريقة صحيحة؟",
  "أعاني من سعال جاف منذ بدء الدواء، ما السبب؟",
];

export function ChatPanel({
  className = "",
  threadId,
  userId,
  initialMessages,
  onThreadsChanged,
}: {
  className?: string;
  threadId: string;
  userId: string;
  initialMessages: UIMessage[];
  onThreadsChanged?: () => void | Promise<void>;
}) {
  const transportRef = useRef(new DefaultChatTransport({ api: "/api/chat" }));
  const isFirstMessage = useRef(initialMessages.length === 0);
  const { messages, sendMessage, error, regenerate, status, stop } = useChat({
    id: threadId,
    messages: initialMessages,
    transport: transportRef.current,
    onFinish: ({ message }) => {
      const text = messageText(message);
      if (!text) return;
      void (async () => {
        await saveMessage({
          threadId,
          userId,
          role: "assistant",
          content: text,
          clientMessageId: message.id,
        });
        await touchThread(threadId);
        await onThreadsChanged?.();
      })().catch(() => {});
    },
  });
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const [input, setInput] = useState("");

  useEffect(() => {
    inputRef.current?.focus();
  }, [threadId, status]);

  const send = (text: string) => {
    if (status !== "ready") return;
    void sendMessage({ text });
    void (async () => {
      await saveMessage({ threadId, userId, role: "user", content: text });
      if (isFirstMessage.current) {
        isFirstMessage.current = false;
        await renameThread(threadId, text.length > 4 ? text : NEW_THREAD_TITLE);
      }
      await touchThread(threadId);
      await onThreadsChanged?.();
    })().catch(() => {});
  };

  useEffect(() => {
    scrollRef.current?.scrollTo({
      top: scrollRef.current.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || status !== "ready") return;
    send(input.trim());
    setInput("");
  };

  const isStreaming = status === "streaming";

  return (
    <section
      className={`flex flex-col overflow-hidden rounded-[2rem] border border-white/5 bg-ocean-800/40 shadow-xl ${className}`}
    >
      <div className="flex items-center justify-between gap-3 border-b border-white/5 p-5">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-ocean-300/15">
            <MessageSquare className="h-4 w-4 text-ocean-300" />
          </div>
          <h2 className="font-bold text-white">مساعدك الصحي الذكي</h2>
        </div>
        <span className="hidden rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold text-white/40 sm:block">
          مبني على دليل WHO 2021
        </span>
      </div>

      <div ref={scrollRef} className="min-h-[40vh] flex-1 overflow-y-auto p-5">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center py-4 text-center">
            <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-ocean-300 to-ocean-500">
              <Stethoscope className="h-7 w-7 text-ocean-900" />
            </div>
            <h3 className="font-sora text-lg font-bold text-white">
              أهلاً بك في نبض 👋
            </h3>
            <p className="mt-2 max-w-md text-sm leading-relaxed text-white/55">
              اسألني أي سؤال عن ارتفاع ضغط الدم، أو اختر من الأسئلة المقترحة.
            </p>
            <div className="mt-5 grid w-full gap-2 sm:grid-cols-2">
              {SUGGESTED_QUESTIONS.map((q) => (
                <button
                  key={q}
                  onClick={() => send(q)}
                  className="rounded-xl border border-white/8 bg-ocean-800/70 px-4 py-3 text-right text-sm text-white/75 transition hover:border-ocean-300/40 hover:bg-ocean-500/20"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="space-y-5">
            {messages.map((m) => (
              <Bubble key={m.id} role={m.role} parts={m.parts} />
            ))}
            {isStreaming && messages[messages.length - 1]?.role === "user" && (
              <Typing />
            )}
          </div>
        )}

        {error && (
          <div className="mt-4 rounded-2xl border border-red-400/25 bg-red-400/10 p-3">
            <p className="text-sm text-red-100">تعذّر الاتصال بالمساعد.</p>
            <button
              onClick={() => regenerate()}
              className="mt-2 text-xs font-semibold text-red-100 underline"
            >
              إعادة المحاولة
            </button>
          </div>
        )}
      </div>

      <div className="bg-ocean-900/40 p-4">
        <form onSubmit={submit} className="flex items-end gap-2">
          <textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                submit(e);
              }
            }}
            rows={1}
            placeholder="اطرح سؤالك عن ضغط الدم..."
            className="min-h-[48px] flex-1 resize-none rounded-2xl border border-white/10 bg-ocean-800 px-4 py-3 text-sm text-white placeholder:text-white/30 focus:border-ocean-300/50 focus:outline-none focus:ring-2 focus:ring-ocean-300/25"
          />
          {isStreaming ? (
            <button
              type="button"
              onClick={stop}
              className="h-12 shrink-0 rounded-2xl bg-white/10 px-4 text-xs font-bold text-white transition hover:bg-white/20"
            >
              إيقاف
            </button>
          ) : (
            <button
              type="submit"
              disabled={!input.trim()}
              aria-label="إرسال"
              className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-ocean-300 text-ocean-900 shadow-lg shadow-ocean-300/15 transition hover:bg-ocean-300/90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <Send className="h-5 w-5 -scale-x-100" />
            </button>
          )}
        </form>
      </div>
    </section>
  );
}

function Bubble({
  role,
  parts,
}: {
  role: "user" | "assistant" | "system";
  parts: { type: string; text?: string }[];
}) {
  const isUser = role === "user";
  return (
    <div className={`flex ${isUser ? "justify-start" : "justify-end"}`}>
      <div
        className={`flex max-w-[85%] gap-2 ${isUser ? "flex-row" : "flex-row-reverse"}`}
      >
        {!isUser && (
          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-2xl bg-ocean-300 text-ocean-900">
            <Stethoscope className="h-4 w-4" />
          </div>
        )}
        <div
          className={`whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${
            isUser
              ? "rounded-tl-none bg-ocean-500/80 text-white"
              : "rounded-tr-none border border-white/5 bg-ocean-800 text-white/85"
          }`}
        >
          {parts.map((part, i) =>
            part.type === "text" ? <span key={i}>{part.text}</span> : null,
          )}
        </div>
      </div>
    </div>
  );
}

function Typing() {
  return (
    <div className="flex justify-end">
      <div className="flex items-center gap-1 rounded-2xl border border-white/5 bg-ocean-800 px-4 py-4">
        <span className="h-2 w-2 animate-bounce rounded-full bg-ocean-300 [animation-delay:-0.3s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-ocean-300 [animation-delay:-0.15s]" />
        <span className="h-2 w-2 animate-bounce rounded-full bg-ocean-300" />
      </div>
    </div>
  );
}