import { createFileRoute, Link } from "@tanstack/react-router";
import { Activity, Droplets, Moon, Pill, Salad, Wind } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { ARTICLES, type Article } from "@/lib/articles";

export const Route = createFileRoute("/library/")({
  head: () => ({
    meta: [
      { title: "المكتبة الصحية — مقالات ارتفاع ضغط الدم | نبض" },
      {
        name: "description",
        content:
          "مقالات عربية مختصرة عن ارتفاع ضغط الدم: الملح والتغذية، نظام داش، القياس الصحيح، الأدوية وأعراضها، النوم والتوتر.",
      },
      { property: "og:title", content: "المكتبة الصحية — نبض" },
      {
        property: "og:description",
        content: "مقالات تثقيفية قصيرة لفهم ضغط الدم وإدارته يومياً.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: LibraryPage,
});

export const ICONS = {
  droplets: Droplets,
  wind: Wind,
  pill: Pill,
  activity: Activity,
  salad: Salad,
  moon: Moon,
} as const;

function LibraryPage() {
  return (
    <AppShell
      title="المكتبة الصحية"
      subtitle="مقالات مختصرة مبنية على دليل منظمة الصحة العالمية 2021"
    >
      <div className="grid gap-5 p-5 md:grid-cols-2 md:p-8">
        {ARTICLES.map((a: Article) => {
          const Icon = ICONS[a.icon];
          return (
            <Link
              key={a.slug}
              to="/library/$slug"
              params={{ slug: a.slug }}
              className="group rounded-[1.75rem] border border-white/5 bg-ocean-800/50 p-6 transition hover:border-ocean-300/30 hover:bg-ocean-800/70"
            >
              <div className="mb-4 flex items-center justify-between">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-ocean-900/60 transition group-hover:bg-ocean-500/70">
                  <Icon className="h-7 w-7 text-ocean-300" />
                </div>
                <span className="rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold text-ocean-300">
                  {a.tag}
                </span>
              </div>
              <h2 className="mb-2 text-lg font-bold text-white transition group-hover:text-ocean-300">
                {a.title}
              </h2>
              <p className="text-sm leading-relaxed text-white/50">
                {a.excerpt}
              </p>
              <p className="mt-4 text-[11px] font-bold text-ocean-300">
                {a.read} قراءة
              </p>
            </Link>
          );
        })}
      </div>
    </AppShell>
  );
}