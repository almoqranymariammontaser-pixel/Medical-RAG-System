import { createFileRoute } from "@tanstack/react-router";
import {
  authenticateRequest,
  classifyReading,
  errorResponse,
  isResponse,
  jsonResponse,
  preflight,
} from "@/lib/api.server";

export const Route = createFileRoute("/api/public/v1/stats")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),

      GET: async ({ request }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        const days = Math.min(
          Math.max(Number(new URL(request.url).searchParams.get("days") ?? 30) || 30, 1),
          365,
        );
        const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();

        const { data, error } = await session.supabase
          .from("readings")
          .select("systolic, diastolic, pulse, measured_at")
          .gte("measured_at", since)
          .order("measured_at", { ascending: false });
        if (error) return errorResponse(error.message, 400);

        const total = data.length;
        const avg = (nums: number[]) =>
          nums.length ? Math.round(nums.reduce((a, b) => a + b, 0) / nums.length) : null;

        const latest = data[0] ?? null;
        const pulses = data.map((r) => r.pulse).filter((p): p is number => typeof p === "number");

        return jsonResponse({
          period_days: days,
          total_readings: total,
          average_systolic: avg(data.map((r) => r.systolic)),
          average_diastolic: avg(data.map((r) => r.diastolic)),
          average_pulse: avg(pulses),
          max_systolic: total ? Math.max(...data.map((r) => r.systolic)) : null,
          min_systolic: total ? Math.min(...data.map((r) => r.systolic)) : null,
          latest: latest
            ? { ...latest, classification: classifyReading(latest.systolic, latest.diastolic) }
            : null,
        });
      },
    },
  },
});