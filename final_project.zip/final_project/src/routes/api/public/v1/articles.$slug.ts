import { createFileRoute } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/articles";
import { errorResponse, jsonResponse, preflight } from "@/lib/api.server";

export const Route = createFileRoute("/api/public/v1/articles/$slug")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),
      GET: async ({ params }) => {
        const article = ARTICLES.find((a) => a.slug === params.slug);
        if (!article) return errorResponse("Article not found.", 404);
        return jsonResponse({ data: article });
      },
    },
  },
});