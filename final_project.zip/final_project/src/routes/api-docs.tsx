import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/app-shell";

export const Route = createFileRoute("/api-docs")({
  head: () => ({
    meta: [
      { title: "توثيق واجهة نبض البرمجية (API) | نبض" },
      {
        name: "description",
        content:
          "توثيق واجهة REST الخاصة بتطبيق نبض: قراءات ضغط الدم، الملف الشخصي، الإحصائيات، المكتبة الصحية، والمساعد الذكي.",
      },
      { property: "og:title", content: "توثيق واجهة نبض البرمجية (API)" },
      {
        property: "og:description",
        content: "كل نقاط النهاية بأمثلة طلب واستجابة جاهزة للتجربة.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ApiDocsPage,
});

type Endpoint = {
  method: "GET" | "POST" | "PATCH" | "DELETE";
  path: string;
  auth: boolean;
  summary: string;
  request?: string;
  response: string;
};

const GROUPS: { title: string; description: string; endpoints: Endpoint[] }[] = [
  {
    title: "عام",
    description: "نقاط لا تحتاج تسجيل دخول.",
    endpoints: [
      {
        method: "GET",
        path: "/api/public/v1/health",
        auth: false,
        summary: "التأكد من أن الواجهة تعمل، مع قائمة بكل نقاط النهاية.",
        response: `{
  "status": "ok",
  "service": "nabd-api",
  "version": "1.0.0"
}`,
      },
      {
        method: "GET",
        path: "/api/public/v1/articles?tag=تغذية",
        auth: false,
        summary: "قائمة مقالات المكتبة الصحية (يمكن التصفية بالوسم).",
        response: `{
  "count": 6,
  "data": [
    { "slug": "sodium-and-blood-pressure", "title": "تأثير الصوديوم على ضغط الدم", "tag": "تغذية" }
  ]
}`,
      },
      {
        method: "GET",
        path: "/api/public/v1/articles/:slug",
        auth: false,
        summary: "مقال كامل بكل أقسامه.",
        response: `{
  "data": {
    "slug": "deep-breathing",
    "title": "التنفس العميق وخفض الضغط",
    "sections": [{ "heading": "الفكرة", "body": ["..."] }]
  }
}`,
      },
      {
        method: "POST",
        path: "/api/public/v1/chat",
        auth: false,
        summary: "سؤال المساعد الذكي المبني على دليل منظمة الصحة العالمية 2021.",
        request: `{
  "message": "هل القهوة ترفع الضغط؟",
  "history": [{ "role": "user", "content": "مرحباً" }]
}`,
        response: `{
  "data": { "reply": "...", "model": "google/gemini-3.7-flash" }
}`,
      },
    ],
  },
  {
    title: "الملف الشخصي",
    description: "يتطلب توكن المستخدم، وكل مستخدم يرى بياناته فقط.",
    endpoints: [
      {
        method: "GET",
        path: "/api/public/v1/profile",
        auth: true,
        summary: "بيانات المستخدم والأهداف العلاجية.",
        response: `{
  "data": { "full_name": "مريم", "target_systolic": 130, "target_diastolic": 80 },
  "email": "user@example.com"
}`,
      },
      {
        method: "PATCH",
        path: "/api/public/v1/profile",
        auth: true,
        summary: "تحديث بيانات الملف الشخصي أو الأهداف.",
        request: `{ "full_name": "مريم", "age": 45, "target_systolic": 125 }`,
        response: `{ "data": { "id": "uuid", "full_name": "مريم", "age": 45 } }`,
      },
    ],
  },
  {
    title: "القراءات",
    description: "إدارة كاملة لقراءات ضغط الدم مع تصنيف تلقائي لكل قراءة.",
    endpoints: [
      {
        method: "GET",
        path: "/api/public/v1/readings?limit=50&offset=0&from=&to=",
        auth: true,
        summary: "قائمة القراءات مرتبة من الأحدث، مع ترقيم صفحات وتصفية بالتاريخ.",
        response: `{
  "count": 12,
  "limit": 50,
  "offset": 0,
  "data": [
    { "id": "uuid", "systolic": 138, "diastolic": 88,
      "classification": { "level": "warn", "label": "مرتفع قليلاً" } }
  ]
}`,
      },
      {
        method: "POST",
        path: "/api/public/v1/readings",
        auth: true,
        summary: "تسجيل قراءة جديدة.",
        request: `{
  "systolic": 138,
  "diastolic": 88,
  "pulse": 76,
  "note": "بعد المشي",
  "measured_at": "2026-08-19T18:30:00.000Z"
}`,
        response: `{ "data": { "id": "uuid", "systolic": 138, "classification": { "level": "warn" } } }`,
      },
      {
        method: "GET",
        path: "/api/public/v1/readings/:id",
        auth: true,
        summary: "قراءة واحدة بالتفصيل.",
        response: `{ "data": { "id": "uuid", "systolic": 138, "diastolic": 88 } }`,
      },
      {
        method: "PATCH",
        path: "/api/public/v1/readings/:id",
        auth: true,
        summary: "تعديل قراءة قائمة (أي حقل أو أكثر).",
        request: `{ "systolic": 132, "note": "إعادة قياس" }`,
        response: `{ "data": { "id": "uuid", "systolic": 132 } }`,
      },
      {
        method: "DELETE",
        path: "/api/public/v1/readings/:id",
        auth: true,
        summary: "حذف قراءة.",
        response: `{ "data": { "id": "uuid", "deleted": true } }`,
      },
      {
        method: "GET",
        path: "/api/public/v1/stats?days=30",
        auth: true,
        summary: "ملخص إحصائي: المتوسطات، الأعلى والأدنى، وآخر قراءة مع تصنيفها.",
        response: `{
  "period_days": 30,
  "total_readings": 12,
  "average_systolic": 134,
  "average_diastolic": 85,
  "latest": { "systolic": 138, "classification": { "level": "warn" } }
}`,
      },
    ],
  },
];

const METHOD_STYLES: Record<Endpoint["method"], string> = {
  GET: "bg-ocean-300/15 text-ocean-300",
  POST: "bg-emerald-400/15 text-emerald-300",
  PATCH: "bg-amber-400/15 text-amber-200",
  DELETE: "bg-red-400/15 text-red-200",
};

function CodeBlock({ label, code }: { label: string; code: string }) {
  return (
    <div>
      <p className="mb-1 text-[11px] font-bold tracking-wide text-white/40">{label}</p>
      <pre
        dir="ltr"
        className="overflow-x-auto rounded-2xl bg-ocean-900/70 p-4 text-left text-xs leading-relaxed text-white/80"
      >
        <code>{code}</code>
      </pre>
    </div>
  );
}

function ApiDocsPage() {
  return (
    <AppShell title="واجهة نبض البرمجية (API)" subtitle="REST v1 — توثيق نقاط النهاية">
      <div className="space-y-8 p-5 md:p-8">
        <section className="rounded-[1.75rem] border border-white/5 bg-ocean-800/50 p-6">
          <h2 className="mb-3 text-lg font-bold text-white">البداية السريعة</h2>
          <p className="mb-4 text-sm leading-relaxed text-white/60">
            جميع النقاط تبدأ بـ <span dir="ltr">/api/public/v1</span> وترجع JSON بترميز UTF-8،
            وتدعم CORS. النقاط المحمية تحتاج ترويسة{" "}
            <span dir="ltr">Authorization: Bearer &lt;access_token&gt;</span> — وهو توكن الجلسة
            الذي يصدره تسجيل الدخول داخل التطبيق. كل طلب محمي يعمل بصلاحيات صاحب التوكن فقط،
            فلا يمكن لمستخدم الوصول إلى بيانات غيره.
          </p>
          <CodeBlock
            label="مثال بـ curl"
            code={`curl -X POST "$BASE_URL/api/public/v1/readings" \\
  -H "Authorization: Bearer $ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"systolic":138,"diastolic":88,"pulse":76}'`}
          />
          <div className="mt-4">
            <CodeBlock
              label="أكواد الاستجابة"
              code={`200 OK          نجاح
201 Created     تم إنشاء المورد
401 Unauthorized  توكن مفقود أو منتهي
404 Not Found     المورد غير موجود
422 Unprocessable بيانات غير صالحة (تفاصيل الحقول في details)
500 / 502         خطأ في الخادم أو خدمة الذكاء الاصطناعي`}
            />
          </div>
        </section>

        {GROUPS.map((group) => (
          <section key={group.title} className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">{group.title}</h2>
              <p className="text-sm text-white/50">{group.description}</p>
            </div>

            {group.endpoints.map((ep) => (
              <article
                key={ep.method + ep.path}
                className="rounded-[1.75rem] border border-white/5 bg-ocean-800/50 p-6"
              >
                <div className="mb-3 flex flex-wrap items-center gap-3">
                  <span
                    className={`rounded-full px-3 py-1 text-[11px] font-bold ${METHOD_STYLES[ep.method]}`}
                  >
                    {ep.method}
                  </span>
                  <code dir="ltr" className="text-sm text-white">
                    {ep.path}
                  </code>
                  <span className="rounded-full bg-white/5 px-3 py-1 text-[10px] font-bold text-white/50">
                    {ep.auth ? "يتطلب توكن" : "بدون توكن"}
                  </span>
                </div>
                <p className="mb-4 text-sm text-white/60">{ep.summary}</p>
                <div className="grid gap-4 md:grid-cols-2">
                  {ep.request && <CodeBlock label="الطلب" code={ep.request} />}
                  <CodeBlock label="الاستجابة" code={ep.response} />
                </div>
              </article>
            ))}
          </section>
        ))}
      </div>
    </AppShell>
  );
}