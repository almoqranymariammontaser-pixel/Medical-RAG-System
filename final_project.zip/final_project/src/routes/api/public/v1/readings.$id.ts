import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import {
  authenticateRequest,
  classifyReading,
  errorResponse,
  isResponse,
  jsonResponse,
  preflight,
} from "@/lib/api.server";

const updateSchema = z
  .object({
    systolic: z.number().int().min(50).max(300),
    diastolic: z.number().int().min(30).max(200),
    pulse: z.number().int().min(20).max(250).nullable(),
    note: z.string().max(500).nullable(),
    measured_at: z.string().datetime(),
  })
  .partial();

export const Route = createFileRoute("/api/public/v1/readings/$id")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),

      GET: async ({ request, params }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        const { data, error } = await session.supabase
          .from("readings")
          .select("*")
          .eq("id", params.id)
          .maybeSingle();
        if (error) return errorResponse(error.message, 400);
        if (!data) return errorResponse("Reading not found.", 404);

        return jsonResponse({
          data: { ...data, classification: classifyReading(data.systolic, data.diastolic) },
        });
      },

      PATCH: async ({ request, params }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return errorResponse("Request body must be valid JSON.", 400);
        }

        const parsed = updateSchema.safeParse(body);
        if (!parsed.success) return errorResponse("Invalid payload.", 422, parsed.error.issues);
        if (Object.keys(parsed.data).length === 0) {
          return errorResponse("No fields to update.", 422);
        }

        const d = parsed.data;
        const patch: Database["public"]["Tables"]["readings"]["Update"] = {
          ...(d.systolic !== undefined ? { systolic: d.systolic } : {}),
          ...(d.diastolic !== undefined ? { diastolic: d.diastolic } : {}),
          ...(d.pulse !== undefined ? { pulse: d.pulse } : {}),
          ...(d.note !== undefined ? { note: d.note } : {}),
          ...(d.measured_at !== undefined ? { measured_at: d.measured_at } : {}),
        };

        const { data, error } = await session.supabase
          .from("readings")
          .update(patch)
          .eq("id", params.id)
          .select()
          .maybeSingle();
        if (error) return errorResponse(error.message, 400);
        if (!data) return errorResponse("Reading not found.", 404);

        return jsonResponse({
          data: { ...data, classification: classifyReading(data.systolic, data.diastolic) },
        });
      },

      DELETE: async ({ request, params }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        const { data, error } = await session.supabase
          .from("readings")
          .delete()
          .eq("id", params.id)
          .select("id")
          .maybeSingle();
        if (error) return errorResponse(error.message, 400);
        if (!data) return errorResponse("Reading not found.", 404);

        return jsonResponse({ data: { id: data.id, deleted: true } });
      },
    },
  },
});