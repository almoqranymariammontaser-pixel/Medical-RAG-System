import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import type { Database } from "@/integrations/supabase/types";
import {
  authenticateRequest,
  errorResponse,
  isResponse,
  jsonResponse,
  preflight,
} from "@/lib/api.server";

const profileSchema = z
  .object({
    full_name: z.string().max(120).nullable(),
    age: z.number().int().min(1).max(120).nullable(),
    gender: z.string().max(20).nullable(),
    target_systolic: z.number().int().min(80).max(200),
    target_diastolic: z.number().int().min(40).max(140),
    notes: z.string().max(1000).nullable(),
  })
  .partial();

export const Route = createFileRoute("/api/public/v1/profile")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),

      GET: async ({ request }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        const { data, error } = await session.supabase
          .from("profiles")
          .select("*")
          .eq("id", session.userId)
          .maybeSingle();
        if (error) return errorResponse(error.message, 400);

        return jsonResponse({ data: data ?? null, email: session.email });
      },

      PATCH: async ({ request }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return errorResponse("Request body must be valid JSON.", 400);
        }

        const parsed = profileSchema.safeParse(body);
        if (!parsed.success) return errorResponse("Invalid payload.", 422, parsed.error.issues);

        const d = parsed.data;
        const patch: Database["public"]["Tables"]["profiles"]["Insert"] = {
          id: session.userId,
          ...(d.full_name !== undefined ? { full_name: d.full_name } : {}),
          ...(d.age !== undefined ? { age: d.age } : {}),
          ...(d.gender !== undefined ? { gender: d.gender } : {}),
          ...(d.target_systolic !== undefined ? { target_systolic: d.target_systolic } : {}),
          ...(d.target_diastolic !== undefined ? { target_diastolic: d.target_diastolic } : {}),
          ...(d.notes !== undefined ? { notes: d.notes } : {}),
        };

        const { data, error } = await session.supabase
          .from("profiles")
          .upsert(patch)
          .select()
          .single();
        if (error) return errorResponse(error.message, 400);

        return jsonResponse({ data });
      },
    },
  },
});