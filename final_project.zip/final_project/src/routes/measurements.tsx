import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Loader2, Plus, Trash2 } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useAuth, useRequireAuth } from "@/lib/auth";
import {
  classify,
  formatDate,
  levelClasses,
  useAddReading,
  useDeleteReading,
  useReadings,
} from "@/lib/health";

export const Route = createFileRoute("/measurements")({
  head: () => ({
    meta: [
      { title: "قياساتي — سجل ضغط الدم | نبض" },
      {
        name: "description",
        content:
          "أضف قياسات ضغط دمك ونبضك واحتفظ بسجلك كاملاً في حسابك، مع تصنيف تلقائي لكل قراءة.",
      },
      { property: "og:title", content: "قياساتي — نبض" },
      {
        property: "og:description",
        content: "سجل قياسات ضغط الدم محفوظ في حسابك الخاص.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: MeasurementsPage,
});

function MeasurementsPage() {
  const { loading, session } = useRequireAuth();
  const { user } = useAuth();
  const { data: readings = [] } = useReadings(user?.id);
  const addReading = useAddReading(user?.id);
  const deleteReading = useDeleteReading(user?.id);

  const [systolic, setSystolic] = useState("");
  const [diastolic, setDiastolic] = useState("");
  const [pulse, setPulse] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState<string | null>(null);

  if (loading || !session) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-ocean-900 font-tajawal text-white/60">
        جارٍ التحميل...
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const sys = Number(systolic);
    const dia = Number(diastolic);
    if (!sys || !dia || sys < 60 || sys > 260 || dia < 30 || dia > 180) {
      setError("أدخل قراءة منطقية: الانقباضي ٦٠–٢٦٠ والانبساطي ٣٠–١٨٠.");
      return;
    }
    try {
      await addReading.mutateAsync({
        systolic: sys,
        diastolic: dia,
        pulse: pulse ? Number(pulse) : null,
        note: note.trim() || null,
      });
      setSystolic("");
      setDiastolic("");
      setPulse("");
      setNote("");
    } catch {
      setError("تعذّر حفظ القياس. حاول مرة أخرى.");
    }
  };

  return (
    <AppShell title="قياساتي" subtitle="كل قياس يُحفظ في حسابك ويظهر في لوحتك">
      <div className="grid gap-5 p-5 md:grid-cols-12 md:p-8">
        <form
          onSubmit={submit}
          className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6 md:col-span-5"
        >
          <h2 className="mb-5 font-bold text-white">إضافة قياس جديد</h2>
          <div className="grid grid-cols-2 gap-3">
            <NumberField
              label="الانقباضي"
              value={systolic}
              onChange={setSystolic}
              placeholder="120"
            />
            <NumberField
              label="الانبساطي"
              value={diastolic}
              onChange={setDiastolic}
              placeholder="80"
            />
          </div>
          <div className="mt-3">
            <NumberField
              label="النبض (اختياري)"
              value={pulse}
              onChange={setPulse}
              placeholder="75"
            />
          </div>
          <label className="mt-3 block">
            <span className="mb-1.5 block text-xs font-bold text-white/50">
              ملاحظة (اختياري)
            </span>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="مثال: بعد الدواء الصباحي"
              className="w-full rounded-2xl border border-white/10 bg-ocean-900/50 px-4 py-3 text-sm text-white placeholder:text-white/25 focus:border-ocean-300/50 focus:outline-none"
            />
          </label>

          {error && (
            <p className="mt-4 rounded-xl border border-red-400/25 bg-red-400/10 p-3 text-xs text-red-100">
              {error}
            </p>
          )}

          <button
            type="submit"
            disabled={addReading.isPending}
            className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-ocean-300 py-3 text-sm font-bold text-ocean-900 transition hover:bg-ocean-300/90 disabled:opacity-50"
          >
            {addReading.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Plus className="h-4 w-4" />
            )}
            حفظ القياس
          </button>
        </form>

        <section className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6 md:col-span-7">
          <h2 className="mb-2 font-bold text-white">السجل</h2>
          {readings.length === 0 ? (
            <p className="mt-4 rounded-2xl bg-ocean-900/40 p-5 text-sm text-white/50">
              لا توجد قياسات بعد.
            </p>
          ) : (
            <ul className="divide-y divide-white/5">
              {readings.map((r) => {
                const c = classify(r.systolic, r.diastolic);
                return (
                  <li
                    key={r.id}
                    className="flex items-center justify-between gap-3 py-4"
                  >
                    <div className="min-w-0">
                      <p className="font-bold">
                        <span className="font-sora text-2xl text-ocean-300">
                          {r.systolic}
                        </span>
                        <span className="text-white/30">/{r.diastolic}</span>
                        <span className="text-xs text-white/35"> ملم زئبق</span>
                      </p>
                      <p className="mt-1 truncate text-xs text-white/40">
                        {formatDate(r.measured_at)}
                        {r.pulse ? ` · نبض ${r.pulse}` : ""}
                        {r.note ? ` · ${r.note}` : ""}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-2">
                      <span
                        className={`rounded-full px-3 py-1 text-[11px] font-bold ${levelClasses(c.level)}`}
                      >
                        {c.label}
                      </span>
                      <button
                        onClick={() => deleteReading.mutate(r.id)}
                        aria-label="حذف القياس"
                        className="rounded-xl p-2 text-white/35 transition hover:bg-white/5 hover:text-red-200"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>
      </div>
    </AppShell>
  );
}

function NumberField({
  label,
  value,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-white/50">
        {label}
      </span>
      <input
        type="number"
        inputMode="numeric"
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-white/10 bg-ocean-900/50 px-4 py-3 text-sm text-white placeholder:text-white/25 focus:border-ocean-300/50 focus:outline-none"
      />
    </label>
  );
}