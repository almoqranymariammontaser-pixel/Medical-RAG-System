import { createFileRoute } from "@tanstack/react-router";
import { jsonResponse, preflight } from "@/lib/api.server";

export const Route = createFileRoute("/api/public/v1/health")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),
      GET: async () =>
        jsonResponse({
          status: "ok",
          service: "nabd-api",
          version: "1.0.0",
          time: new Date().toISOString(),
          endpoints: [
            "GET    /api/public/v1/health",
            "GET    /api/public/v1/articles",
            "GET    /api/public/v1/articles/:slug",
            "GET    /api/public/v1/profile",
            "PATCH  /api/public/v1/profile",
            "GET    /api/public/v1/readings",
            "POST   /api/public/v1/readings",
            "GET    /api/public/v1/readings/:id",
            "PATCH  /api/public/v1/readings/:id",
            "DELETE /api/public/v1/readings/:id",
            "GET    /api/public/v1/stats",
            "POST   /api/public/v1/chat",
          ],
        }),
    },
  },
});