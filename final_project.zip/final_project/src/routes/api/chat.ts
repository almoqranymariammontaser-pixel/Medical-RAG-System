import { createFileRoute } from "@tanstack/react-router";
import { streamText, convertToModelMessages, type UIMessage } from "ai";
import { createLovableAiGatewayProvider, DEFAULT_CHAT_MODEL } from "@/lib/ai-gateway.server";
import { buildSystemPrompt } from "@/lib/kb.server";

export const Route = createFileRoute("/api/chat")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const body = (await request.json()) as { messages: UIMessage[] };
        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) {
          return new Response(
            JSON.stringify({ error: "LOVABLE_API_KEY غير مضبوط على الخادم." }),
            { status: 500, headers: { "content-type": "application/json; charset=utf-8" } },
          );
        }

        const provider = createLovableAiGatewayProvider(apiKey);

        try {
          const result = streamText({
            model: provider(DEFAULT_CHAT_MODEL),
            system: buildSystemPrompt(),
            messages: await convertToModelMessages(body.messages),
          });

          return result.toUIMessageStreamResponse();
        } catch (err) {
          const message = err instanceof Error ? err.message : "حدث خطأ غير متوقع.";
          return new Response(JSON.stringify({ error: message }), {
            status: 500,
            headers: { "content-type": "application/json; charset=utf-8" },
          });
        }
      },
    },
  },
});