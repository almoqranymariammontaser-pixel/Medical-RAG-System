import { createFileRoute } from "@tanstack/react-router";
import { ARTICLES } from "@/lib/articles";
import { jsonResponse, preflight } from "@/lib/api.server";

export const Route = createFileRoute("/api/public/v1/articles")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),
      GET: async ({ request }) => {
        const tag = new URL(request.url).searchParams.get("tag");
        const items = ARTICLES.filter((a) => !tag || a.tag === tag).map((a) => ({
          slug: a.slug,
          title: a.title,
          tag: a.tag,
          read: a.read,
          excerpt: a.excerpt,
        }));
        return jsonResponse({ count: items.length, data: items });
      },
    },
  },
});