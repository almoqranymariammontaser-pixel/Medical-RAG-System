import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Loader2, LogOut, Save } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { useAuth, useRequireAuth } from "@/lib/auth";
import { useProfile, useSaveProfile } from "@/lib/health";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "الإعدادات وملفي الصحي — نبض" },
      {
        name: "description",
        content:
          "حدّث اسمك وعمرك وضغطك المستهدف وملاحظاتك الصحية، وكل ذلك محفوظ في حسابك الخاص بنبض.",
      },
      { property: "og:title", content: "الإعدادات وملفي الصحي — نبض" },
      {
        property: "og:description",
        content: "ملفك الصحي وهدفك العلاجي في مكان واحد.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SettingsPage,
});

function SettingsPage() {
  const { loading, session } = useRequireAuth();
  const { user, signOut } = useAuth();
  const { data: profile } = useProfile(user?.id);
  const saveProfile = useSaveProfile(user?.id);

  const [fullName, setFullName] = useState("");
  const [age, setAge] = useState("");
  const [targetSys, setTargetSys] = useState("130");
  const [targetDia, setTargetDia] = useState("80");
  const [notes, setNotes] = useState("");
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (!profile) return;
    setFullName(profile.full_name ?? "");
    setAge(profile.age ? String(profile.age) : "");
    setTargetSys(String(profile.target_systolic));
    setTargetDia(String(profile.target_diastolic));
    setNotes(profile.notes ?? "");
  }, [profile]);

  if (loading || !session) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-ocean-900 font-tajawal text-white/60">
        جارٍ التحميل...
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(false);
    await saveProfile.mutateAsync({
      full_name: fullName.trim() || null,
      age: age ? Number(age) : null,
      target_systolic: Number(targetSys) || 130,
      target_diastolic: Number(targetDia) || 80,
      notes: notes.trim() || null,
    });
    setSaved(true);
  };

  return (
    <AppShell title="الإعدادات" subtitle="ملفك الصحي وهدفك العلاجي">
      <div className="grid gap-5 p-5 md:grid-cols-12 md:p-8">
        <form
          onSubmit={submit}
          className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6 md:col-span-7"
        >
          <h2 className="mb-5 font-bold text-white">ملفي الصحي</h2>

          <Field label="الاسم" value={fullName} onChange={setFullName} />
          <div className="mt-3 grid grid-cols-3 gap-3">
            <Field label="العمر" value={age} onChange={setAge} type="number" />
            <Field
              label="الهدف الانقباضي"
              value={targetSys}
              onChange={setTargetSys}
              type="number"
            />
            <Field
              label="الهدف الانبساطي"
              value={targetDia}
              onChange={setTargetDia}
              type="number"
            />
          </div>

          <label className="mt-3 block">
            <span className="mb-1.5 block text-xs font-bold text-white/50">
              ملاحظات صحية (أمراض مصاحبة، أدوية)
            </span>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full resize-none rounded-2xl border border-white/10 bg-ocean-900/50 px-4 py-3 text-sm text-white placeholder:text-white/25 focus:border-ocean-300/50 focus:outline-none"
            />
          </label>

          {saved && (
            <p className="mt-4 rounded-xl border border-ocean-300/25 bg-ocean-300/10 p-3 text-xs text-ocean-300">
              تم الحفظ بنجاح.
            </p>
          )}

          <button
            type="submit"
            disabled={saveProfile.isPending}
            className="mt-5 flex items-center justify-center gap-2 rounded-2xl bg-ocean-300 px-6 py-3 text-sm font-bold text-ocean-900 transition hover:bg-ocean-300/90 disabled:opacity-50"
          >
            {saveProfile.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            حفظ
          </button>
        </form>

        <div className="flex flex-col gap-5 md:col-span-5">
          <div className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6">
            <h2 className="mb-3 font-bold text-white">الحساب</h2>
            <p className="text-sm text-white/55">{user?.email}</p>
            <button
              onClick={() => signOut()}
              className="mt-5 flex items-center gap-2 rounded-2xl border border-white/10 px-4 py-2.5 text-xs font-bold text-white/70 transition hover:border-red-300/40 hover:text-red-200"
            >
              <LogOut className="h-4 w-4" />
              تسجيل الخروج
            </button>
          </div>

          <div className="rounded-[2rem] border border-white/5 bg-ocean-800/50 p-6">
            <h2 className="mb-3 font-bold text-white">حول نبض</h2>
            <ul className="space-y-2 text-sm leading-relaxed text-white/55">
              <li>• مساعد تثقيفي مبني على دليل منظمة الصحة العالمية 2021.</li>
              <li>• لا يقدّم تشخيصاً ولا يوصف جرعات أدوية.</li>
              <li>• في الأعراض الخطيرة يوجّهك للطوارئ فوراً.</li>
              <li>• قياساتك وملفك محفوظان في حسابك فقط.</li>
            </ul>
          </div>
        </div>
      </div>
    </AppShell>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
}) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-xs font-bold text-white/50">
        {label}
      </span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-2xl border border-white/10 bg-ocean-900/50 px-4 py-3 text-sm text-white focus:border-ocean-300/50 focus:outline-none"
      />
    </label>
  );
}