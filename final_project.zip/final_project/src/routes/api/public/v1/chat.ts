import { createFileRoute } from "@tanstack/react-router";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider, DEFAULT_CHAT_MODEL } from "@/lib/ai-gateway.server";
import { buildSystemPrompt } from "@/lib/kb.server";
import { errorResponse, jsonResponse, preflight } from "@/lib/api.server";

const chatSchema = z.object({
  message: z.string().min(1).max(2000),
  history: z
    .array(z.object({ role: z.enum(["user", "assistant"]), content: z.string().max(4000) }))
    .max(20)
    .optional(),
});

export const Route = createFileRoute("/api/public/v1/chat")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),

      POST: async ({ request }) => {
        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return errorResponse("Request body must be valid JSON.", 400);
        }

        const parsed = chatSchema.safeParse(body);
        if (!parsed.success) return errorResponse("Invalid payload.", 422, parsed.error.issues);

        const apiKey = process.env["LOVABLE_API_KEY"];
        if (!apiKey) return errorResponse("AI service is not configured.", 500);

        try {
          const provider = createLovableAiGatewayProvider(apiKey);
          const result = await generateText({
            model: provider(DEFAULT_CHAT_MODEL),
            system: buildSystemPrompt(),
            messages: [
              ...(parsed.data.history ?? []),
              { role: "user" as const, content: parsed.data.message },
            ],
          });

          return jsonResponse({ data: { reply: result.text, model: DEFAULT_CHAT_MODEL } });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Unexpected AI gateway error.";
          return errorResponse(message, 502);
        }
      },
    },
  },
});