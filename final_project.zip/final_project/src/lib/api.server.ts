import { createClient, type SupabaseClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

/** Shared CORS headers so the API can be called from external clients/tools. */
export const CORS_HEADERS: Record<string, string> = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,POST,PATCH,DELETE,OPTIONS",
  "access-control-allow-headers": "authorization, content-type",
};

export function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body, null, 2), {
    status,
    headers: { "content-type": "application/json; charset=utf-8", ...CORS_HEADERS },
  });
}

export function errorResponse(message: string, status = 400, details?: unknown): Response {
  return jsonResponse({ error: { message, status, details: details ?? null } }, status);
}

export function preflight(): Response {
  return new Response(null, { status: 204, headers: CORS_HEADERS });
}

export type ApiSession = {
  supabase: SupabaseClient<Database>;
  userId: string;
  email: string | null;
};

/**
 * Authenticates an API request with the caller's `Authorization: Bearer <access_token>`.
 * The returned client runs with the user's own privileges, so row level security
 * keeps every request scoped to that user's data.
 */
export async function authenticateRequest(request: Request): Promise<ApiSession | Response> {
  const header = request.headers.get("authorization") ?? "";
  const token = header.toLowerCase().startsWith("bearer ") ? header.slice(7).trim() : "";
  if (!token) {
    return errorResponse("Missing 'Authorization: Bearer <access_token>' header.", 401);
  }

  const url = process.env["SUPABASE_URL"];
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"];
  if (!url || !key) return errorResponse("Server is not configured.", 500);

  const supabase = createClient<Database>(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { Authorization: `Bearer ${token}`, apikey: key } },
  });

  const { data, error } = await supabase.auth.getUser(token);
  if (error || !data.user) return errorResponse("Invalid or expired access token.", 401);

  return { supabase, userId: data.user.id, email: data.user.email ?? null };
}

export function isResponse(value: unknown): value is Response {
  return value instanceof Response;
}

/** Blood-pressure classification shared by the API and the app UI. */
export function classifyReading(systolic: number, diastolic: number) {
  if (systolic >= 180 || diastolic >= 110) return { level: "danger", label: "خطر — راجع الطوارئ" };
  if (systolic >= 140 || diastolic >= 90) return { level: "high", label: "مرتفع" };
  if (systolic >= 130 || diastolic >= 85) return { level: "warn", label: "مرتفع قليلاً" };
  if (systolic < 90 || diastolic < 60) return { level: "warn", label: "منخفض" };
  return { level: "ok", label: "ضمن النطاق المقبول" };
}