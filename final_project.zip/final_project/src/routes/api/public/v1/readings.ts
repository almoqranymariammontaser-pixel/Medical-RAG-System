import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import {
  authenticateRequest,
  classifyReading,
  errorResponse,
  isResponse,
  jsonResponse,
  preflight,
} from "@/lib/api.server";

const createSchema = z.object({
  systolic: z.number().int().min(50).max(300),
  diastolic: z.number().int().min(30).max(200),
  pulse: z.number().int().min(20).max(250).nullable().optional(),
  note: z.string().max(500).nullable().optional(),
  measured_at: z.string().datetime().optional(),
});

export const Route = createFileRoute("/api/public/v1/readings")({
  server: {
    handlers: {
      OPTIONS: async () => preflight(),

      GET: async ({ request }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        const url = new URL(request.url);
        const limit = Math.min(Number(url.searchParams.get("limit") ?? 50) || 50, 200);
        const offset = Math.max(Number(url.searchParams.get("offset") ?? 0) || 0, 0);
        const from = url.searchParams.get("from");
        const to = url.searchParams.get("to");

        let query = session.supabase
          .from("readings")
          .select("*", { count: "exact" })
          .order("measured_at", { ascending: false })
          .range(offset, offset + limit - 1);
        if (from) query = query.gte("measured_at", from);
        if (to) query = query.lte("measured_at", to);

        const { data, error, count } = await query;
        if (error) return errorResponse(error.message, 400);

        return jsonResponse({
          count: count ?? data.length,
          limit,
          offset,
          data: data.map((r) => ({ ...r, classification: classifyReading(r.systolic, r.diastolic) })),
        });
      },

      POST: async ({ request }) => {
        const session = await authenticateRequest(request);
        if (isResponse(session)) return session;

        let body: unknown;
        try {
          body = await request.json();
        } catch {
          return errorResponse("Request body must be valid JSON.", 400);
        }

        const parsed = createSchema.safeParse(body);
        if (!parsed.success) return errorResponse("Invalid payload.", 422, parsed.error.issues);

        const payload = {
          user_id: session.userId,
          systolic: parsed.data.systolic,
          diastolic: parsed.data.diastolic,
          pulse: parsed.data.pulse ?? null,
          note: parsed.data.note ?? null,
          measured_at: parsed.data.measured_at ?? new Date().toISOString(),
        };

        const { data, error } = await session.supabase
          .from("readings")
          .insert(payload)
          .select()
          .single();
        if (error) return errorResponse(error.message, 400);

        return jsonResponse(
          { data: { ...data, classification: classifyReading(data.systolic, data.diastolic) } },
          201,
        );
      },
    },
  },
});