import { createFileRoute, useNavigate, useParams } from "@tanstack/react-router";
import { MessageSquarePlus, Trash2 } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import type { UIMessage } from "ai";
import { AppShell } from "@/components/app-shell";
import { ChatPanel } from "@/components/chat-panel";
import { useRequireAuth } from "@/lib/auth";
import {
  createThread,
  deleteThread,
  listThreads,
  loadThreadMessages,
  type ChatThread,
} from "@/lib/chat-store";

export const Route = createFileRoute("/chat/$threadId")({
  head: () => ({
    meta: [
      { title: "المحادثة مع المساعد — نبض" },
      {
        name: "description",
        content:
          "محادثاتك المحفوظة مع مساعد نبض التثقيفي حول ارتفاع ضغط الدم، الأدوية، القياس والتغذية.",
      },
      { property: "og:title", content: "المحادثة مع المساعد — نبض" },
      {
        property: "og:description",
        content: "إجابات عربية مبسّطة عن ضغط الدم مع حفظ سجل المحادثات.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatThreadPage,
});

function ChatThreadPage() {
  const { loading, session } = useRequireAuth();
  const { threadId } = useParams({ from: "/chat/$threadId" });
  const navigate = useNavigate();
  const [threads, setThreads] = useState<ChatThread[]>([]);
  const [initialMessages, setInitialMessages] = useState<UIMessage[] | null>(null);

  const refreshThreads = useCallback(async () => {
    try {
      setThreads(await listThreads());
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!session) return;
    void refreshThreads();
  }, [session, refreshThreads]);

  useEffect(() => {
    if (!session) return;
    let cancelled = false;
    setInitialMessages(null);
    loadThreadMessages(threadId)
      .then((msgs) => {
        if (!cancelled) setInitialMessages(msgs);
      })
      .catch(() => {
        if (!cancelled) setInitialMessages([]);
      });
    return () => {
      cancelled = true;
    };
  }, [threadId, session]);

  const onNewThread = async () => {
    if (!session) return;
    const thread = await createThread(session.user.id);
    await refreshThreads();
    navigate({ to: "/chat/$threadId", params: { threadId: thread.id } });
  };

  const onDelete = async (id: string) => {
    if (!session) return;
    await deleteThread(id);
    const rest = (await listThreads()).filter((t) => t.id !== id);
    setThreads(rest);
    if (id === threadId) {
      const next = rest[0] ?? (await createThread(session.user.id));
      await refreshThreads();
      navigate({
        to: "/chat/$threadId",
        params: { threadId: next.id },
        replace: true,
      });
    }
  };

  if (loading || !session) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-ocean-900 font-tajawal text-white/60">
        جارٍ التحميل...
      </div>
    );
  }

  return (
    <AppShell title="المحادثة مع المساعد">
      <div className="grid gap-5 p-5 md:grid-cols-[16rem_1fr] md:p-8">
        <aside className="flex max-h-[26rem] flex-col overflow-hidden rounded-[2rem] border border-white/5 bg-ocean-800/40 md:max-h-[calc(100dvh-16rem)]">
          <button
            onClick={() => void onNewThread()}
            className="m-4 flex items-center justify-center gap-2 rounded-2xl bg-ocean-300 px-4 py-3 text-sm font-bold text-ocean-900 transition hover:bg-ocean-300/90"
          >
            <MessageSquarePlus className="h-4 w-4" />
            محادثة جديدة
          </button>
          <div className="flex-1 space-y-1 overflow-y-auto px-3 pb-4">
            {threads.map((thread) => {
              const active = thread.id === threadId;
              return (
                <div
                  key={thread.id}
                  className={`group flex items-center gap-1 rounded-xl px-2 transition ${
                    active ? "bg-ocean-500/70" : "hover:bg-white/5"
                  }`}
                >
                  <button
                    onClick={() =>
                      navigate({
                        to: "/chat/$threadId",
                        params: { threadId: thread.id },
                      })
                    }
                    className={`flex-1 truncate py-3 text-right text-sm ${
                      active ? "font-bold text-white" : "text-white/60"
                    }`}
                  >
                    {thread.title}
                  </button>
                  <button
                    onClick={() => void onDelete(thread.id)}
                    aria-label="حذف المحادثة"
                    className="shrink-0 rounded-lg p-2 text-white/30 transition hover:bg-red-400/15 hover:text-red-200"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              );
            })}
            {threads.length === 0 && (
              <p className="px-3 py-4 text-xs text-white/35">
                لا توجد محادثات محفوظة بعد.
              </p>
            )}
          </div>
        </aside>

        {initialMessages === null ? (
          <div className="flex min-h-[26rem] items-center justify-center rounded-[2rem] border border-white/5 bg-ocean-800/40 text-sm text-white/50">
            جارٍ تحميل المحادثة...
          </div>
        ) : (
          <ChatPanel
            key={threadId}
            threadId={threadId}
            userId={session.user.id}
            initialMessages={initialMessages}
            onThreadsChanged={refreshThreads}
            className="h-[calc(100dvh-16rem)] min-h-[26rem]"
          />
        )}
      </div>
    </AppShell>
  );
}